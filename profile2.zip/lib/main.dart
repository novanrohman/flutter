import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:profile2/pages/profile.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp();

  void _onTap(int index) {
    setState(() {
      _selectedItem = index;
    });

    @override
    Widget build(BuildContext context) {
      return MaterialApp(
        home: Scaffold(
          appBar: AppBar(
            title: Text("My App"),
          ),
          body: Profile(),
          bottomNavigationBar: BottomNavigationBar(
              currentIndex: _selectedItem,
              onTap: _onTap,
              items: [
                BottomNavigationBarItem(
                  icon: Icon(Icons.home),
                  label: "Home",
                ),
                BottomNavigationBarItem(
                    icon: Icon(Icons.people), label: "Profile")
              ]),
        ),
      );
    }
  }
}
